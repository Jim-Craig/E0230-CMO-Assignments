# Pyarmor 8.5.12 (trial), 000000, 2024-10-08T22:51:59.581163
from .pyarmor_runtime import __pyarmor__
