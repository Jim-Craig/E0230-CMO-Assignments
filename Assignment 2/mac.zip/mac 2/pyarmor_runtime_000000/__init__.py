# Pyarmor 8.5.12 (trial), 000000, 2024-10-08T23:13:36.252929
from .pyarmor_runtime import __pyarmor__
