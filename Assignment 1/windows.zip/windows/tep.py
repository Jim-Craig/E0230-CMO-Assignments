from CMO_A1 import f1, f2, f3, f4
import numpy as np
sr_num = 12345
print(f1(sr_num,2))
print(f2(sr_num, 5))
print(f3(sr_num, 3))
print(f4(sr_num, np.array([0.0,0.0,0.0,0.0,0.0])))